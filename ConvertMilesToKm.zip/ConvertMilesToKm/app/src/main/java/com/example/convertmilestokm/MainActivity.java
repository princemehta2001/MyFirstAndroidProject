package com.example.convertmilestokm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button b1= (Button) findViewById(R.id.Km2Miles);
        b1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void  onClick(View v) {
                EditText km = (EditText) findViewById(R.id.Km);
                EditText miles = (EditText) findViewById(R.id.Miles);
                String kms=km.getText().toString().trim();
                if(kms.length()<=0||!kms.matches("[0-9]+(\\.[0-9]+)?"))
                {
                    miles.setText("");
                    openDialog();
                }
               else
                {
                    double kmv=Double.valueOf(kms);
                    double milesv=kmv*0.621371;
                    miles.setText(String.format("%.3f",milesv));
                }
            }
        });
        Button b2= (Button) findViewById(R.id.Miles2Km);
        b2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void  onClick(View v) {
                EditText km = (EditText) findViewById(R.id.Km);
                EditText miles = (EditText) findViewById(R.id.Miles);
                String miless=miles.getText().toString().trim();
                if(miless.length()<=0||!miless.matches("[0-9]+(\\.[0-9]+)?"))
                {
                    km.setText("");
                    openDialog();
                }
                else
                {
                    double milesv=Double.parseDouble(miless);
                    double kmv=milesv/0.621371;
                    km.setText(String.format("%.3f",kmv));
                }
            }
        });
    }
    public void openDialog()
    {
        ExampleDialog exapleDialog= new ExampleDialog();
        exapleDialog.show(getSupportFragmentManager(),"Alert Message");
    }
}